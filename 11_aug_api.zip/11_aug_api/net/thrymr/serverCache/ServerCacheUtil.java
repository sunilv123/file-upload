package net.thrymr.serverCache;

import java.util.concurrent.ConcurrentHashMap;

public class ServerCacheUtil {
	
	public static final  ConcurrentHashMap<String, Object> CURRENT_USER  = new ConcurrentHashMap<String, Object>();
	
	public static final ConcurrentHashMap<String, Object> CONCURRENT_LTP = new ConcurrentHashMap<String, Object>();
	
	public static final ConcurrentHashMap<String, Object> CONCURRENT_ISIN = new ConcurrentHashMap<String, Object>();
	
	public static final ConcurrentHashMap<String, Object> CONCURRENT_SCRIP = new ConcurrentHashMap<String, Object>();
	
}
