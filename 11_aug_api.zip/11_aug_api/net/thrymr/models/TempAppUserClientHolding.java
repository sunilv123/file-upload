package net.thrymr.models;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class TempAppUserClientHolding extends BaseEntity{
	
	
	@Indexed
	@NotNull
	@DBRef
	public AppUser appUser;
	
	@Indexed
	@NotNull
	public String name;

	@Indexed
	@NotNull
	public String ISIN;
	
	@NotNull
	public String clientCode;
	
	public String SecurityScripName;

	public Float FundingPercentage;

	public Integer MarginQuantity;

	public Integer UnapprovedQuantity;

	public Integer TotalQuantity;

	public Integer MarketRate;
	
	public Integer ApprovedMarketValue;
	
	public Integer NonApprovedMarketValue;
	
	public Integer TotalMarketValue;
	
	public BigDecimal DrawingPower;
	
}
