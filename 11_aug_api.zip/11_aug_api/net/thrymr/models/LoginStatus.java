package net.thrymr.models;

public enum LoginStatus {

	LOGGED_IN,

	LOGGED_OUT,

	EXPIRED

}
