package net.thrymr.models;

import java.math.BigDecimal;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class CapitalLine extends BaseEntity{

	public Integer CO_CODE;
	
	public String ISIN_No;

	public String CO_NAME;
	
	public String Company_Long_Name; 
	
	public String CAT_1;
	
	public String Year_End_Latest;
	
	public String Year_End_Latest1;
	
	public Float CAGR_Net_Sales_3_Yrs;
	
	public Float CAGR_Net_Sales_5_Yrs;
	
	//public String Year_End_Latest;

	public Float PBIDTM_Latest_Percenatge;
	
	//public String Year_End_Latest1;
	
	public Float PBIDTM_Latest1_Percenatge;
	
	public Float PBIDTM_1_Y_Avg_Change;
	
	public String Year_End_Latest2;
	
	public Float PBIDTM_Latest2_Percenatge;
	
	public String  Year_End_Latest3;
	
    public Float PBIDTM_Latest3_Percenatge;
    
    public Float PBIDTM_3_Y_Avg_Change; 
	
	public String Year_End_Latest4;
	
	public Float PBIDTM_Latest4_Percenatge;
	 
	public String Year_End_Latest5;
	
	public Float PBIDTM_Latest5_Percenatge;
	
	public Float PBIDTM_5_Y_Avg_Change;
	
	public Float ROCE_Latest_Percentage;
	
	public Float RONW_Latest_Percentage;
	
	public String Year_Month_Latest;
	
	public Float Total_of_Promoter_and_Group_Latest_Holding;
	
	//public String Year_Month_Latest;
	
	public Float Total_of_Promoter_and_Group_Latest_Pledge;
	
	//public String Year_End_Latest;
	
	//public String Year_End_Latest1;
	
	//public String Year_End_Latest2;
	
	public Float Net_Cash_from_Operating_Activities_Latest;
	
	public Float Net_Cash_from_Operating_Activities_Latest1;
	
	public Float Net_Cash_from_Operating_Activities_Latest2;
	
	public Float  Net_Cash_from_Operating_Activities_Total;
	
	public Float  Other_Income_Latest;
	
	public Float  Operating_Profit_Latest;
	
	public Float EBIDTA;
	
	public Float CFO_EBIDTA;
	
	public String BSE_As_On_Date_Latest;
	
	public BigDecimal BSE_Weekly_Total_Volume_Latest;
	
	public BigDecimal BSE_Monthly_Total_Volume_Latest;
	
	public BigDecimal BSE_Yearly_Total_Volume_Latest;
	
	public String NSE_As_On_Date_Latest;
	
	public BigDecimal  NSE_Weekly_Total_Volume_Latest;
	
	public BigDecimal  NSE_Monthly_Total_Volume_Latest;
	
	public BigDecimal  NSE_Yearly_Total_Volume_Latest;
	
	public BigDecimal Weekly_Total_Volume;
	
	public BigDecimal Monthly_Total_Volume;
	
	public BigDecimal Yearly_Total_Volume;
	
	//public String BSE_As_On_Date_Latest;
	
	public BigDecimal BSE_Weekly_Total_Deliverable_Volume_Latest;
	
	public BigDecimal BSE_Monthly_Total_Deliverable_Volume_Latest;
	
	public BigDecimal BSE_Yearly_Total_Deliverable_Volume_Latest;
	
	//public String NSE_As_On_Date_Latest;
	
	public BigDecimal NSE_Weekly_Total_Deliverable_Volume_Latest;
	
	public BigDecimal NSE_Monthly_Total_Deliverable_Volume_Latest;
	
	public BigDecimal NSE_Yearly_Total_Deliverable_Volume_Latest;
	
	public BigDecimal Weekly_Total_Delivery_Volume;
	
	public BigDecimal Monthly_Total_Delivery_Volume;
	
	public BigDecimal Yearly_Total_Delivery_Volume;
	
	public String Year_And_Month_Latest;
	
	public BigDecimal Total_of_Promoter_and_Group_Latest;
	
	public BigDecimal Grand_Total_Latest;
	
	public BigDecimal Free_Float_Shares;
	
	public Float Week_52_Low_Unit_Curr_BSE;
	
	public String Week_52_Low_Date_BSE;
	
	//public String Year_End_Latest;
	
	//public String Year_End_Latest1;
	
	//public String Year_End_Latest2;
	
	//public String Year_End_Latest3;
	
	public Float EV_EBIDTA_Latest;
	
	public Float EV_EBIDTA_Latest1;
	
	public Float EV_EBIDTA_Latest2;
	
	public Float EV_EBIDTA_Change_over_1_year;
	
	public Float EV_EBIDTA_Latest3;
	
	public Float EV_EBIDTA_Change_over_3_year;
	
	public Float Price_Earning_Latest;
	
	public Float Price_Earning_Latest1;
	
	public Float Price_Earning_Change_over_1_year;
	
	public Float Price_Earning_Latest2;
	
	public Float Price_Earning_Latest3;

	public Float Price_Earning_Change_over_3_year;
	
	public Float Total_Debt_Divide_Loan_Funds_Latest;//[Total Debt / Loan Funds (Latest)]
	
	public Float Debt_to_EBIDTA;
	
	public Float Debt_Equity_Ratio_Latest;
			
	public Float Profit_Before_Tax_Latest;
	
	public Float Interest_Latest;
	
	public Float EBIT_Divide_Interest;//EBIT / Interest
	
	public String Price_Date;
	
	public Float Market_Capitalisation_BSE;
	
	public Float Latest_Market_Price_Unit_Curr_BSE;
	
	public String NSE_Date_Latest;
	
	public Float NSE_VaR_Margin;
	
    public String BSE_Date_Latest;
	
	public Float BSE_VaR_Margin;
	
	public Integer BSE_Code;
	                         
	public String BSE_Group;
	
	public String Industry_As_per_BSE;
	
}
