package net.thrymr.models;

import java.math.BigDecimal;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class PledgeData extends BaseEntity{

	public String company;

	public Integer BSE_Code;

	public BigDecimal Total_Number_Of_Issued_Shares;

	public BigDecimal  No_of_Shares_for_Total_Promoter_Holding;

	public Float  Total_Promoter_Holding_Percentage;
	
	public BigDecimal Total_Public_Holding;
	
	public BigDecimal  percentage_of_No_of_Shares_for_Promoter_Shares_Encumbered_as_of_last_quarter;
	
	public Float   percentage_of_Promoter_shares_for_Promoter_Shares_Encumbered_as_of_last_quarter;
	
	public Float  percentage_of_total_shares_for_Promoter_Shares_Encumbered_as_of_last_quarter;
	
	public Float Values_for_Promoter_Shares_Encumbered_as_of_last_quarter;
	
	public String disclosures_made_by_promoters_on_their_encumbered_shares_under_Regulation_31_of_SAST_since_the_last_quarter ;
	
	public BigDecimal  No_of_shares_pledged_for_No_of_shares_pledged_in_the_depository_system;
	
	public BigDecimal Total_no_of_demat_shares_for_N0_of_shares_pledged_in_the_depository_system;
	
	public Float No_of_shares_pledged_in_the_depository_system;
	
	public Float Values_forNo_of_shares_pledged_in_the_depository_system ;
	
	public BigDecimal Promoter_shares_for_No_of_shares_held_with_NBFCs_as_collateral_against_lending;
	
	public BigDecimal Non_Promoter_shares_for_No_of_shares_held_with_NBFCs_as_collateral_against_lending;
	
}
