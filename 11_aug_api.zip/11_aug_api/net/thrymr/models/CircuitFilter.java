package net.thrymr.models;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class CircuitFilter extends BaseEntity{

	@Indexed
	public String ISIN;
	
	public Integer CIRCUIT;
	
}
