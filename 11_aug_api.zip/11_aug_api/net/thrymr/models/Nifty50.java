package net.thrymr.models;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Nifty50 extends BaseEntity {

}
