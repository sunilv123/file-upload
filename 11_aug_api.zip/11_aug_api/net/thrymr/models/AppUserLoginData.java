package net.thrymr.models;

import java.util.Date;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class AppUserLoginData extends BaseEntity{

	@NotNull
	@DBRef
	@Indexed
	public AppUser AppUser;

	@NotNull
	@Indexed
	public String xAuth;

	@NotNull
	@Indexed
	public Date date;

	@NotNull
	@Indexed
	public LoginStatus loginStatus;

}
