package net.thrymr.models;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class AppUser extends BaseEntity {

	@NotNull
	@Indexed(unique = true)
	public String userCode;

	public String firstName;

	public String lastName;

	@Indexed(unique = true)
	public String userName;

	public String email;

	public String domain;

	public String mobileNumber;

	@Indexed
	public String socketSessionId;

	@Indexed
	public Boolean isOnline = Boolean.FALSE;

	@Indexed
	public Boolean isActive = Boolean.FALSE;


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (this.id == null ? 0 : this.id.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final AppUser other = (AppUser) obj;
		if (this.id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!this.id.equals(other.id)) {
			return false;
		}
		return true;
	}

}
