package net.thrymr.models;

public enum Role {

	SUPER_ADMIN,

	ADMIN,

	RELATIONSHIP_MANAGER

}
