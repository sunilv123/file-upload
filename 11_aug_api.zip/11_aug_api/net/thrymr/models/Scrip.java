package net.thrymr.models;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Scrip extends BaseEntity{


	@Indexed
	@NotNull
	public String name;

	@Indexed
	@NotNull
	public String ISIN;
	
	@Indexed
	@NotNull
	public String clientCode;
	
	@DBRef
	@NotNull
	@Indexed
	public Client client;
	
	public String SecurityScripName;  

	public Float FundingPercentage;

	public Integer MarginQuantity;

	public Integer UnapprovedQuantity;

	public Integer TotalQuantity;

	public Integer MarketRate;
	
	public Integer ApprovedMarketValue;
	
	public Integer NonApprovedMarketValue;
	
	public Integer TotalMarketValue;
	
	public BigDecimal DrawingPower;
	
  
}


