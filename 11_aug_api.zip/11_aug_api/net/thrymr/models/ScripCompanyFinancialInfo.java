package net.thrymr.models;

import java.util.Date;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class ScripCompanyFinancialInfo {

	@NotNull
	@Indexed
	@DBRef
	public Scrip scrip;

	@NotNull
	@Indexed
	public Date asOfDate;

	public Double previousDayClosingPrice;

	public Double marketCap;

	public Double totalDebt;

	public Double PBIDT;

	public Double debtToEBIDTA;

	public Double PAT;

	public Double cashFlow;

	public Double EBIDTToCFO;

	public Double debtEquityRatio;

	public Double PERatio;

	public Double EVToEBIDTA;

	public Double PToBV;

	public Double ROCEpercentage;

	public Double quarterlyAvgTurnOverBSE;

	public Double quarterlyAvgTurnOverNSE;

	public Double quarterlyTotalTurnOverBSE;

	public Double quarterlyTotalTurnOverNSE;

	public Double quarterlyAvgDeliverableBSE;

	public Double quarterlyAvgDeliverableNSE;

	public Double totalAvgDelivery;

	public Double quarterlyTotalDeliverableBSE;

	public Double quarterlyTotalDeliverableNSE;

	public Double EPSannualised;

	public Double promoterAndGroupTotal;

	public Double freeFloat;

	public Double nonPromoterTotal;

	//	public Double promoterPledge;
	//
	//	public Double VAR;





















}
