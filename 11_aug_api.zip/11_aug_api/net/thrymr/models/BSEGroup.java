package net.thrymr.models;

public enum BSEGroup {

	A,
	B,
	E,
	F,
	FC,
	GC,
	P
}
