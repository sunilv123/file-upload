package net.thrymr.models;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Client extends BaseEntity{

	@NotNull
	@Indexed
	public String name;

	@NotNull
	@Indexed(unique = true)
	public String clientCode;

	/*@NotNull
	public String panNumber;*/
	
	public BigDecimal outstandingLoanBalance;
	
	public Float ROI;

}