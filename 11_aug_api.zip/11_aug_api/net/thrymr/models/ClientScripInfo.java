package net.thrymr.models;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class ClientScripInfo extends BaseEntity{

	@DBRef
	@NotNull
	@Indexed
	public Client client;

	@DBRef
	@NotNull
	@Indexed
	public Scrip scrip;
	
	@DBRef
	@NotNull
	@Indexed
	public AppUser appUser;
	

}
