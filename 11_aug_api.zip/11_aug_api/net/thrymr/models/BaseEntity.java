package net.thrymr.models;

import java.sql.Timestamp;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public String id;

	@JsonIgnore
	public Timestamp createdDate;

	@JsonIgnore
	public Timestamp lastUpdate;

}
