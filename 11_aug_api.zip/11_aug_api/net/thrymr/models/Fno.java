package net.thrymr.models;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Fno extends BaseEntity {

}
