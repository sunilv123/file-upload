package net.thrymr.models;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class AppUserClientInfo extends BaseEntity{

	@DBRef
	@NotNull
	@Indexed
	public AppUser appUser;

	@DBRef
	@NotNull
	@Indexed
	public Client client;

}
