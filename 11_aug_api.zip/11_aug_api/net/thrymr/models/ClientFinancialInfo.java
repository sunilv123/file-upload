package net.thrymr.models;

import java.util.Date;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@Deprecated
public class ClientFinancialInfo {

	@NotNull
	@Indexed
	@DBRef
	public Client client;

	@NotNull
	@Indexed
	public Date asOfDate;

	public Double loanOutstanding;

	public Double marketCap;

	public Double marketValue;

	public Double cat1Value;

	public Double dpPercentage;

	public Double dpValue;

	public Double loanValue;

}
