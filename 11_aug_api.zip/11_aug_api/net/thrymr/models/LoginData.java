package net.thrymr.models;

import java.util.Date;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author Bharath P
 * @createdOn 14-Mar-2017
 */

@Document
public class LoginData extends BaseEntity {

	@NotNull
	@Indexed
	public String xAuth;

	@NotNull
	@DBRef
	@Indexed
	public AppUser appUser;

	public Long expiryTime;

	public LoginStatus loginStatus;

	public Date logInDate;

	public Date logOutDate;
}
