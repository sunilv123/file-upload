package net.thrymr.models;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.sun.istack.internal.NotNull;

@Document
public class LTP extends BaseEntity{

	public String exchange;

	public String symbol;

	public String series;

	public String name;

	public String token;

	@Indexed
	@NotNull
	public String isinVal;

	@Indexed
	public Long timeStamp;

	public Float closingPrice;// last day closing price

	public Integer lastTradedPrice;// current market price(/100)

}
