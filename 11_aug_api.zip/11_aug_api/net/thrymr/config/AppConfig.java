package net.thrymr.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@Configuration
@PropertySource("classpath:application.yml")
@ComponentScan(basePackages = { "net.thrymr.*" })
@EnableAutoConfiguration
@EnableMongoRepositories(basePackages = { "net.thrymr.repo" })
//@EnableAsync
@EnableScheduling
public class AppConfig {

	/*
	 * @Bean(name = "primaryDataSource")
	 * 
	 * @Primary
	 * 
	 * @ConfigurationProperties(prefix = "datasource.primary") public DataSource
	 * primaryDataSource() { return DataSourceBuilder.create().build(); }
	 * 
	 * @Bean public JpaVendorAdapter jpaVendorAdapter() {
	 * HibernateJpaVendorAdapter vendorAdapter = new
	 * HibernateJpaVendorAdapter(); // vendorAdapter.setShowSql(true);
	 * vendorAdapter.setGenerateDdl(true); return vendorAdapter; }
	 */
}
