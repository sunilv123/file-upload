package net.thrymr.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import net.thrymr.beans.GenericResponse;
import net.thrymr.beans.LoginBean;
import net.thrymr.services.LoginService;
import net.thrymr.services.PushMessageService;
import net.thrymr.utils.Constants;

@CrossOrigin
@RestController
public class LoginController {

	@Autowired
	PushMessageService pushMessageService;

	@Autowired
	LoginService loginService;

	// @RequestMapping("/test")
	// public String test(){
	//
	// this.pushMessageService.pushSocketMessage(
	// "/edelweiss-subscribe/receive-direct-message/" + "edel", "Welcome
	// Socket");
	//
	// return "Yay!!!";
	// }

	@PostMapping("/login")
	public GenericResponse login(@RequestBody final LoginBean loginBean, final HttpServletRequest request)
			throws Exception {
		LoginBean bean = loginService.findUserInLDAP(loginBean, request);
		return bean != null
				? new GenericResponse(Constants.GENERIC_RESPONSE_SUCCESS,
						bean)
				: new GenericResponse(Constants.GENERIC_RESPONSE_FAILURE);
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public GenericResponse logout(@RequestHeader("X-Authorization") final String xAuth,
			final HttpServletRequest servletRequest) throws Exception {
		return this.loginService.logout(xAuth, servletRequest.getRequestURL().toString(),
				servletRequest.getRemoteAddr()) != null ? new GenericResponse(Constants.GENERIC_RESPONSE_SUCCESS)
						: new GenericResponse(Constants.GENERIC_RESPONSE_FAILURE);
	}
	
	@GetMapping("/test")
	public GenericResponse testMethod() throws Exception {
		System.out.println("test--------");
		return new GenericResponse(Constants.GENERIC_RESPONSE_SUCCESS);
	}
	
	
	
}
