package net.thrymr.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletResponse;

import net.thrymr.beans.GenericResponse;
import net.thrymr.models.CapitalLine;
import net.thrymr.models.CircuitFilter;
import net.thrymr.models.PledgeData;
import net.thrymr.repo.CapitalLineRepository;
import net.thrymr.repo.CircuitFilterRepository;
import net.thrymr.repo.PledgeDataRepository;
import net.thrymr.services.ScripService;

import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mongodb.gridfs.GridFSDBFile;

//import net.thrymr.services.SampleService;

@RestController
public class SampleController {

	@Autowired
	ScripService scripService;

	@Autowired
	private GridFsTemplate gridFsTemplate;
	
	@Autowired
	CapitalLineRepository capitalLineRepository;
	
	@Autowired
	PledgeDataRepository pledgeDataRepository;
	
	@Autowired
	CircuitFilterRepository circuitFilterRepository;
	
	
	@PostMapping(value = ("upload-cline-file"), headers = ("content-type=multipart/*"))
	public String uploadCapitalLineFile(@RequestPart("file") MultipartFile multipartFile) throws Exception {
		
		System.out.println("upload-cline-file--------------------------------");
		
		final File file = this.convertMultiPartFileToFile(multipartFile);

		FileInputStream fileIS = new FileInputStream(file);
	
		XSSFWorkbook workbook = new XSSFWorkbook(fileIS);

		XSSFSheet sheet = workbook.getSheetAt(0);
		
		Iterator<Row> rowIterator = sheet.iterator();
		
		for (CapitalLine capitalLine : capitalLineRepository.findAll()) {
			capitalLineRepository.delete(capitalLine);
		 }
		
		 CapitalLine capitalLine = null;
		
		 int excelIndex = 0;
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				if (excelIndex > 2) {

					capitalLine = new CapitalLine();
						
					try{
					    Double CO_CODE =  row.getCell(0).getNumericCellValue();
					    capitalLine.CO_CODE = CO_CODE.intValue();
					}catch(Exception e){
						//e.printStackTrace();
						capitalLine.CO_CODE = 0;
					}
					    //System.out.println("excelIndex---  "+excelIndex);
					    capitalLine.CO_NAME = row.getCell(1).getStringCellValue();

						capitalLine.Company_Long_Name = row.getCell(2).getStringCellValue();
						   
					    capitalLine.ISIN_No = row.getCell(3).getStringCellValue();
						
					    try{
						capitalLine.CAT_1 = row.getCell(4).getStringCellValue();
					    }catch(Exception e){
					    	//e.printStackTrace();
					    	capitalLine.CAT_1 = "";
					    }
						
						capitalLine.Year_End_Latest = row.getCell(5).getNumericCellValue()+"";
						
						capitalLine.Year_End_Latest1 = row.getCell(6).getNumericCellValue()+"";
						
						Double CAGR_Net_Sales_3_Yrs =  row.getCell(7).getNumericCellValue();
						capitalLine.CAGR_Net_Sales_3_Yrs = CAGR_Net_Sales_3_Yrs.floatValue();
						
						Double CAGR_Net_Sales_5_Yrs =  row.getCell(8).getNumericCellValue();
						capitalLine.CAGR_Net_Sales_5_Yrs = CAGR_Net_Sales_5_Yrs.floatValue();
						
						//9
						
						Double PBIDTM_Latest_Percenatge =  row.getCell(10).getNumericCellValue();
						capitalLine.PBIDTM_Latest_Percenatge = PBIDTM_Latest_Percenatge.floatValue();
						
						//11
						
						
						Double PBIDTM_Latest1_Percenatge =  row.getCell(12).getNumericCellValue();
						capitalLine.PBIDTM_Latest1_Percenatge = PBIDTM_Latest1_Percenatge.floatValue();
						
						try{
						Double PBIDTM_1_Y_Avg_Change =  row.getCell(13).getNumericCellValue();
						capitalLine.PBIDTM_1_Y_Avg_Change = PBIDTM_1_Y_Avg_Change.floatValue();
						//System.out.println("capitalLine.PBIDTM_1_Y_Avg_Change----------  "+capitalLine.PBIDTM_1_Y_Avg_Change);
						}catch(Exception e){
							//e.printStackTrace();
							capitalLine.PBIDTM_1_Y_Avg_Change = 0f;
						}
						capitalLine.Year_End_Latest2 = row.getCell(15).getNumericCellValue()+""; 
						
						Double PBIDTM_Latest2_Percenatge =  row.getCell(15).getNumericCellValue();
						capitalLine.PBIDTM_Latest2_Percenatge = PBIDTM_Latest2_Percenatge.floatValue();
						
						capitalLine.Year_End_Latest3 = row.getCell(16).getNumericCellValue()+"";
						
						Double PBIDTM_Latest3_Percenatge =  row.getCell(17).getNumericCellValue();
						capitalLine.PBIDTM_Latest3_Percenatge = PBIDTM_Latest3_Percenatge.floatValue();
						
						try{
						Double PBIDTM_3_Y_Avg_Change =  row.getCell(18).getNumericCellValue();
						capitalLine.PBIDTM_3_Y_Avg_Change = PBIDTM_3_Y_Avg_Change.floatValue();
						}catch(Exception e){
							//e.printStackTrace();
							capitalLine.PBIDTM_3_Y_Avg_Change = 0f;
						}
						capitalLine.Year_End_Latest4 = row.getCell(19).getNumericCellValue()+"";
						
						Double PBIDTM_Latest4_Percenatge =  row.getCell(20).getNumericCellValue();
						capitalLine.PBIDTM_Latest4_Percenatge = PBIDTM_Latest4_Percenatge.floatValue();
						
						capitalLine.Year_End_Latest5 = row.getCell(21).getNumericCellValue()+""; 
						
						Double PBIDTM_Latest5_Percenatge =  row.getCell(22).getNumericCellValue();
						capitalLine.PBIDTM_Latest5_Percenatge = PBIDTM_Latest5_Percenatge.floatValue();
						
						try{
						Double PBIDTM_5_Y_Avg_Change =  row.getCell(23).getNumericCellValue();
						capitalLine.PBIDTM_5_Y_Avg_Change = PBIDTM_5_Y_Avg_Change.floatValue();
						}catch(Exception e){
							//e.printStackTrace();
							capitalLine.PBIDTM_5_Y_Avg_Change = 0f;
						}
						
						try{
						Double ROCE_Latest_Percentage =  row.getCell(24).getNumericCellValue();
						capitalLine.ROCE_Latest_Percentage = ROCE_Latest_Percentage.floatValue();
						}catch(Exception e){
							//e.printStackTrace();
							capitalLine.ROCE_Latest_Percentage = 0f;
						}
						
						try{
						Double RONW_Latest_Percentage =  row.getCell(25).getNumericCellValue();
						capitalLine.RONW_Latest_Percentage = RONW_Latest_Percentage.floatValue();
						}catch(Exception e){
							//e.printStackTrace();
							capitalLine.RONW_Latest_Percentage = 0f;
						}
						
						capitalLine.Year_And_Month_Latest = row.getCell(26).getNumericCellValue()+""; 
						
						Double Total_of_Promoter_and_Group_Latest_Holding =  row.getCell(27).getNumericCellValue();
						capitalLine.Total_of_Promoter_and_Group_Latest_Holding = Total_of_Promoter_and_Group_Latest_Holding.floatValue();
						
						//28
						
						Double Total_of_Promoter_and_Group_Latest_Pledge =  row.getCell(29).getNumericCellValue();
						capitalLine.Total_of_Promoter_and_Group_Latest_Pledge= Total_of_Promoter_and_Group_Latest_Pledge.floatValue();
						
						//30,31,32
						
						Double Net_Cash_from_Operating_Activities_Latest =  row.getCell(33).getNumericCellValue();
						capitalLine.Net_Cash_from_Operating_Activities_Latest= Net_Cash_from_Operating_Activities_Latest.floatValue();
							
						Double Net_Cash_from_Operating_Activities_Latest1 =  row.getCell(34).getNumericCellValue();
						capitalLine.Net_Cash_from_Operating_Activities_Latest1= Net_Cash_from_Operating_Activities_Latest1.floatValue();
							
						Double Net_Cash_from_Operating_Activities_Latest2 =  row.getCell(35).getNumericCellValue();
						capitalLine.Net_Cash_from_Operating_Activities_Latest2= Net_Cash_from_Operating_Activities_Latest2.floatValue();
						
						Double Net_Cash_from_Operating_Activities_Total =  row.getCell(36).getNumericCellValue();
						capitalLine.Net_Cash_from_Operating_Activities_Total= Net_Cash_from_Operating_Activities_Total.floatValue();
								
						Double Other_Income_Latest =  row.getCell(37).getNumericCellValue();
						capitalLine.Other_Income_Latest= Other_Income_Latest.floatValue();
						
						Double Operating_Profit_Latest =  row.getCell(38).getNumericCellValue();
						capitalLine.Operating_Profit_Latest= Operating_Profit_Latest.floatValue();
								
						Double EBIDTA = row.getCell(39).getNumericCellValue();
						capitalLine.EBIDTA = EBIDTA.floatValue();
						
						Double CFO_EBIDTA = row.getCell(40).getNumericCellValue();
						capitalLine.CFO_EBIDTA = CFO_EBIDTA.floatValue();
						
						capitalLine.BSE_As_On_Date_Latest = row.getCell(41).getNumericCellValue()+""; 
						
						capitalLine.BSE_Weekly_Total_Volume_Latest = new BigDecimal(row.getCell(42).getNumericCellValue());
						
						capitalLine.BSE_Monthly_Total_Volume_Latest = new BigDecimal(row.getCell(43).getNumericCellValue());
						
						capitalLine.BSE_Yearly_Total_Volume_Latest = new BigDecimal(row.getCell(44).getNumericCellValue());
						
						capitalLine.NSE_As_On_Date_Latest = row.getCell(45).getNumericCellValue()+"";
						
                        capitalLine.NSE_Weekly_Total_Volume_Latest = new BigDecimal(row.getCell(46).getNumericCellValue());
						
						capitalLine.NSE_Monthly_Total_Volume_Latest = new BigDecimal(row.getCell(47).getNumericCellValue());
						
						capitalLine.NSE_Yearly_Total_Volume_Latest = new BigDecimal(row.getCell(48).getNumericCellValue());
						
                        capitalLine.Weekly_Total_Volume = new BigDecimal(row.getCell(49).getNumericCellValue());
						
						capitalLine.Monthly_Total_Volume = new BigDecimal(row.getCell(50).getNumericCellValue());
						
						capitalLine.Yearly_Total_Volume = new BigDecimal(row.getCell(51).getNumericCellValue());
						
						//52
						
						capitalLine.BSE_Weekly_Total_Deliverable_Volume_Latest = new BigDecimal(row.getCell(53).getNumericCellValue());
						
						capitalLine.BSE_Monthly_Total_Deliverable_Volume_Latest = new BigDecimal(row.getCell(54).getNumericCellValue());
						
						capitalLine.BSE_Yearly_Total_Deliverable_Volume_Latest = new BigDecimal(row.getCell(55).getNumericCellValue());
						
						capitalLine.NSE_As_On_Date_Latest = row.getCell(56).getNumericCellValue()+"";
						
		                capitalLine.NSE_Weekly_Total_Deliverable_Volume_Latest = new BigDecimal(row.getCell(57).getNumericCellValue());
						
						capitalLine.NSE_Monthly_Total_Deliverable_Volume_Latest = new BigDecimal(row.getCell(58).getNumericCellValue());
						
						capitalLine.NSE_Yearly_Total_Deliverable_Volume_Latest = new BigDecimal(row.getCell(59).getNumericCellValue());
						
						capitalLine.Weekly_Total_Delivery_Volume = new BigDecimal(row.getCell(60).getNumericCellValue());
						
						capitalLine.Monthly_Total_Delivery_Volume = new BigDecimal(row.getCell(61).getNumericCellValue());
						
						capitalLine.Yearly_Total_Delivery_Volume = new BigDecimal(row.getCell(62).getNumericCellValue());
						
						//63
						
						capitalLine.Total_of_Promoter_and_Group_Latest = new BigDecimal(row.getCell(64).getNumericCellValue());
						
						capitalLine.Grand_Total_Latest = new BigDecimal(row.getCell(65).getNumericCellValue());
						
						capitalLine.Free_Float_Shares = new BigDecimal(row.getCell(66).getNumericCellValue());
						
						Double Week_52_Low_Unit_Curr_BSE =  row.getCell(67).getNumericCellValue();
						capitalLine.Week_52_Low_Unit_Curr_BSE = Week_52_Low_Unit_Curr_BSE.floatValue();
						
						capitalLine.Week_52_Low_Date_BSE = row.getCell(68).getNumericCellValue()+"";
						
						capitalLine.Year_End_Latest = row.getCell(69).getNumericCellValue()+"";  
						
						capitalLine.Year_End_Latest1 = row.getCell(70).getNumericCellValue()+"";  
						
						capitalLine.Year_End_Latest2 = row.getCell(71).getNumericCellValue()+"";  
						
						capitalLine.Year_End_Latest3 =row.getCell(72).getNumericCellValue()+"";  
						
						Double EV_EBIDTA_Latest =  row.getCell(73).getNumericCellValue();
						capitalLine.EV_EBIDTA_Latest = EV_EBIDTA_Latest.floatValue();
						
						Double EV_EBIDTA_Latest1 =  row.getCell(74).getNumericCellValue();
						capitalLine.EV_EBIDTA_Latest1 = EV_EBIDTA_Latest1.floatValue();
						
						Double EV_EBIDTA_Latest2 =  row.getCell(75).getNumericCellValue();
						capitalLine.EV_EBIDTA_Latest2 = EV_EBIDTA_Latest2.floatValue();
						
						Double EV_EBIDTA_Change_over_1_year =  row.getCell(76).getNumericCellValue();
						capitalLine.EV_EBIDTA_Change_over_1_year = EV_EBIDTA_Change_over_1_year.floatValue();

						Double EV_EBIDTA_Latest3 =  row.getCell(77).getNumericCellValue();
						capitalLine.EV_EBIDTA_Latest3 = EV_EBIDTA_Latest3.floatValue();
						
						Double Price_Earning_Latest =  row.getCell(78).getNumericCellValue();
						capitalLine.Price_Earning_Latest = Price_Earning_Latest.floatValue();
						
						Double EV_EBIDTA_Change_over_3_year =  row.getCell(79).getNumericCellValue();
						capitalLine.EV_EBIDTA_Change_over_3_year = EV_EBIDTA_Change_over_3_year.floatValue();
						
						Double Price_Earning_Latest1 =  row.getCell(80).getNumericCellValue();
						capitalLine.Price_Earning_Latest1 = Price_Earning_Latest1.floatValue();
						
						Double Price_Earning_Change_over_1_year =  row.getCell(81).getNumericCellValue();
						capitalLine.Price_Earning_Change_over_1_year = Price_Earning_Change_over_1_year.floatValue();

						
						Double Price_Earning_Latest2 =  row.getCell(82).getNumericCellValue();
						capitalLine.Price_Earning_Latest2 = Price_Earning_Latest2.floatValue();
						
						Double Price_Earning_Latest3 =  row.getCell(83).getNumericCellValue();
						capitalLine.Price_Earning_Latest3 = Price_Earning_Latest3.floatValue();
						
						Double Price_Earning_Change_over_3_year =  row.getCell(84).getNumericCellValue();
						capitalLine.Price_Earning_Change_over_3_year = Price_Earning_Change_over_3_year.floatValue();

						Double Total_Debt_Divide_Loan_Funds_Latest =  row.getCell(85).getNumericCellValue();
						capitalLine.Total_Debt_Divide_Loan_Funds_Latest = Total_Debt_Divide_Loan_Funds_Latest.floatValue();

						try{
						Double Debt_to_EBIDTA =  row.getCell(86).getNumericCellValue();
						capitalLine.Debt_to_EBIDTA = Debt_to_EBIDTA.floatValue();
						}catch(Exception e){
							//e.printStackTrace();
							capitalLine.Debt_to_EBIDTA = 0f;
						}

						Double Debt_Equity_Ratio_Latest =  row.getCell(87).getNumericCellValue();
						capitalLine.Debt_Equity_Ratio_Latest = Debt_Equity_Ratio_Latest.floatValue();

						Double Profit_Before_Tax_Latest =  row.getCell(88).getNumericCellValue();
						capitalLine.Profit_Before_Tax_Latest = Profit_Before_Tax_Latest.floatValue();

						Double Interest_Latest =  row.getCell(89).getNumericCellValue();
						capitalLine.Interest_Latest = Interest_Latest.floatValue();

						try{
						Double EBIT_Divide_Interest =  row.getCell(90).getNumericCellValue();
						capitalLine.EBIT_Divide_Interest = EBIT_Divide_Interest.floatValue();
						}catch(Exception e){
							//e.printStackTrace();
							capitalLine.EBIT_Divide_Interest = 0f;
						}
						capitalLine.Price_Date = row.getCell(91).getNumericCellValue()+"";
			
						Double Market_Capitalisation_BSE =  row.getCell(92).getNumericCellValue();
						capitalLine.Market_Capitalisation_BSE = Market_Capitalisation_BSE.floatValue();
						
						Double Latest_Market_Price_Unit_Curr_BSE =  row.getCell(93).getNumericCellValue();
						capitalLine.Latest_Market_Price_Unit_Curr_BSE = Latest_Market_Price_Unit_Curr_BSE.floatValue();
						
						try{
						capitalLine.NSE_Date_Latest = row.getCell(94).getNumericCellValue()+"";
						}catch(Exception e){
							//e.printStackTrace();
							capitalLine.NSE_Date_Latest = "";
						}
						try{
						Double NSE_VaR_Margin =  row.getCell(95).getNumericCellValue();
						capitalLine.NSE_VaR_Margin = NSE_VaR_Margin.floatValue();
						}catch(Exception e){
							//e.printStackTrace();
							capitalLine.NSE_VaR_Margin = 0f;
						}
						try{
						capitalLine.BSE_Date_Latest = row.getCell(96).getNumericCellValue()+"";
						}catch(Exception e){
							//e.printStackTrace();
							capitalLine.BSE_Date_Latest = "";
						}
						try{
						Double BSE_VaR_Margin =  row.getCell(97).getNumericCellValue();
						capitalLine.BSE_VaR_Margin = BSE_VaR_Margin.floatValue();
						}catch(Exception e){
							//e.printStackTrace();
							capitalLine.BSE_VaR_Margin = 0f;
						}
						Double BSE_Code =  row.getCell(98).getNumericCellValue();
						capitalLine.BSE_Code = BSE_Code.intValue();
						
						capitalLine.BSE_Group = row.getCell(99).getStringCellValue();
						
						capitalLine.Industry_As_per_BSE = row.getCell(100).getStringCellValue();
						
						capitalLineRepository.save(capitalLine);
				
				}
				excelIndex++;
			}	
		 

		fileIS.close();
	
		file.delete();
		// Store the file in database & return the id 
		return "success";
	}
	
	
	
	
	@PostMapping(value = ("upload-pledge-file"), headers = ("content-type=multipart/*"))
	public String uploadPledgeFile(@RequestPart("file") MultipartFile multipartFile) throws Exception {
		
		System.out.println("upload-pledge-file--------------------------------");
		
		final File file = this.convertMultiPartFileToFile(multipartFile);

		FileInputStream fileIS = new FileInputStream(file);
	
		//Get the workbook instance for XLS file 
		XSSFWorkbook workbook = new XSSFWorkbook(fileIS);

		//Get first sheet from the workbook
		XSSFSheet sheet = workbook.getSheetAt(0);
		
		//Iterate through each rows from first sheet
		Iterator<Row> rowIterator = sheet.iterator();
		
		for (PledgeData pledgeData : pledgeDataRepository.findAll()) {
			pledgeDataRepository.delete(pledgeData);
		 }
		 PledgeData pledgeData = null;
		
		 int excelIndex = 0;
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				if (excelIndex > 1) {

					 pledgeData = new PledgeData();
					 
					pledgeData.company = row.getCell(0).getStringCellValue();
					
					Double BSE_Code = row.getCell(1).getNumericCellValue();
					pledgeData.BSE_Code = BSE_Code.intValue();
					
					if(row.getCell(2) != null){
						pledgeData.Total_Number_Of_Issued_Shares = new BigDecimal(row.getCell(2).getNumericCellValue());
					}else{
						pledgeData.Total_Number_Of_Issued_Shares = new BigDecimal(0);
					}

					if(row.getCell(3) != null){
						pledgeData.No_of_Shares_for_Total_Promoter_Holding = new BigDecimal(row.getCell(3).getNumericCellValue());
					}else{
						pledgeData.No_of_Shares_for_Total_Promoter_Holding = new BigDecimal(0);
					}

				
                     if(row.getCell(4) != null){
                    	 Double Total_Promoter_Holding_Percentage = row.getCell(4).getNumericCellValue();
                    	 pledgeData.Total_Promoter_Holding_Percentage = Total_Promoter_Holding_Percentage.floatValue();
                     }else{
                    	 pledgeData.Total_Promoter_Holding_Percentage = 0f;
                     }
					

                     if(row.getCell(5) != null){
                    	 pledgeData.Total_Public_Holding = new BigDecimal(row.getCell(5).getNumericCellValue());
                     }else{
                    	 pledgeData.Total_Public_Holding = new BigDecimal(0);
                     }
					
                     if(row.getCell(6) != null){
                    	 pledgeData.percentage_of_No_of_Shares_for_Promoter_Shares_Encumbered_as_of_last_quarter = new BigDecimal(row.getCell(6).getNumericCellValue());
                     }else{
                    	 pledgeData.percentage_of_No_of_Shares_for_Promoter_Shares_Encumbered_as_of_last_quarter = new BigDecimal(0);
                     }
                     
                     if(row.getCell(7) != null){
                    		Double percentage_of_Promoter_shares_for_Promoter_Shares_Encumbered_as_of_last_quarter = row.getCell(7).getNumericCellValue();
        					pledgeData.percentage_of_Promoter_shares_for_Promoter_Shares_Encumbered_as_of_last_quarter = percentage_of_Promoter_shares_for_Promoter_Shares_Encumbered_as_of_last_quarter.floatValue();
        					
                     }else{
                    	 pledgeData.percentage_of_Promoter_shares_for_Promoter_Shares_Encumbered_as_of_last_quarter = 0f;
                     }
                     
                     if(row.getCell(8) != null){
                    		Double percentage_of_total_shares_for_Promoter_Shares_Encumbered_as_of_last_quarter = row.getCell(8).getNumericCellValue();
        					pledgeData.percentage_of_total_shares_for_Promoter_Shares_Encumbered_as_of_last_quarter = percentage_of_total_shares_for_Promoter_Shares_Encumbered_as_of_last_quarter.floatValue();
	                  }else{
	                	      pledgeData.percentage_of_total_shares_for_Promoter_Shares_Encumbered_as_of_last_quarter = 0f;
	                  }
                     
				
					if(row.getCell(9) != null){
						Double Values_for_Promoter_Shares_Encumbered_as_of_last_quarter = row.getCell(9).getNumericCellValue();
						pledgeData.Values_for_Promoter_Shares_Encumbered_as_of_last_quarter = Values_for_Promoter_Shares_Encumbered_as_of_last_quarter.floatValue();
					}else{
						pledgeData.Values_for_Promoter_Shares_Encumbered_as_of_last_quarter = 0f;
					}
					if(row.getCell(10) != null){
						pledgeData.disclosures_made_by_promoters_on_their_encumbered_shares_under_Regulation_31_of_SAST_since_the_last_quarter = row.getCell(10).getStringCellValue();
					}else{
						pledgeData.disclosures_made_by_promoters_on_their_encumbered_shares_under_Regulation_31_of_SAST_since_the_last_quarter = "";
					}
					
					 if(row.getCell(11) != null){
						 pledgeData.No_of_shares_pledged_for_No_of_shares_pledged_in_the_depository_system = new BigDecimal(row.getCell(11).getNumericCellValue());
                     }else{
                    	 pledgeData.No_of_shares_pledged_for_No_of_shares_pledged_in_the_depository_system = new BigDecimal(0);
                     }
					
					 if(row.getCell(12) != null){
						 pledgeData.Total_no_of_demat_shares_for_N0_of_shares_pledged_in_the_depository_system = new BigDecimal(row.getCell(12).getNumericCellValue());
                     }else{
                    	 pledgeData.Total_no_of_demat_shares_for_N0_of_shares_pledged_in_the_depository_system = new BigDecimal(0);
                     }
				
					if(row.getCell(13) != null){
						Double No_of_shares_pledged_in_the_depository_system = row.getCell(13).getNumericCellValue();
						pledgeData.No_of_shares_pledged_in_the_depository_system = No_of_shares_pledged_in_the_depository_system.floatValue();
					}else{
						pledgeData.No_of_shares_pledged_in_the_depository_system = 0f;
					}
			
					if(row.getCell(14) != null){
						Double Values_forNo_of_shares_pledged_in_the_depository_system = row.getCell(14).getNumericCellValue();
						pledgeData.Values_forNo_of_shares_pledged_in_the_depository_system = Values_forNo_of_shares_pledged_in_the_depository_system.floatValue();
					}else{
						pledgeData.Values_forNo_of_shares_pledged_in_the_depository_system = 0f;
					}
				
                    if(row.getCell(15) != null){
                    	pledgeData.Promoter_shares_for_No_of_shares_held_with_NBFCs_as_collateral_against_lending = new BigDecimal(row.getCell(15).getNumericCellValue());
                    }else{
                    	pledgeData.Promoter_shares_for_No_of_shares_held_with_NBFCs_as_collateral_against_lending = new BigDecimal(0);
                    }
                    if(row.getCell(16) != null){
					 pledgeData.Non_Promoter_shares_for_No_of_shares_held_with_NBFCs_as_collateral_against_lending = new BigDecimal(row.getCell(16).getNumericCellValue());
                    }else{
                    	pledgeData.Non_Promoter_shares_for_No_of_shares_held_with_NBFCs_as_collateral_against_lending = new BigDecimal(0);	
                    }
					
					pledgeDataRepository.save(pledgeData);
				
				}
				excelIndex++;
			}	
		fileIS.close();
		/**
		 * The file(which is no longer required) which has been created inside
		 * project will be deleted
		 */
		file.delete();
		// Store the file in database & return the id 
		return "success";
	}

	@PostMapping(value = ("upload-circuit-breaker-file"), headers = ("content-type=multipart/*"))
	public String uploadCircuitBreakerFile(@RequestPart("file") MultipartFile multipartFile) throws Exception {

		System.out.println("upload-circuit-file--------------------------------");
		
		final File file = this.convertMultiPartFileToFile(multipartFile);

		FileInputStream fileIS = new FileInputStream(file);
	
		//Get the workbook instance for XLS file 
		XSSFWorkbook workbook = new XSSFWorkbook(fileIS);

		//Get first sheet from the workbook
		XSSFSheet sheet = workbook.getSheetAt(0);
		
		//Iterate through each rows from first sheet
		Iterator<Row> rowIterator = sheet.iterator();
		
		 CircuitFilter circuitFilter= null;
		
		 ;
		 for (CircuitFilter ciFilter : circuitFilterRepository.findAll()) {
			 circuitFilterRepository.delete(ciFilter);
		 }
		 
		 
		 int excelIndex = 0;
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				if (excelIndex > 0) {

					circuitFilter = new CircuitFilter();
					circuitFilter.ISIN = row.getCell(0).getStringCellValue();
					
					circuitFilter.ISIN = row.getCell(0).getStringCellValue();
				
					Double CIRCUIT = row.getCell(1).getNumericCellValue();
					circuitFilter.CIRCUIT = CIRCUIT.intValue();
					
					circuitFilterRepository.save(circuitFilter);
				}
				excelIndex++;
			}	
		fileIS.close();
		/**
		 * The file(which is no longer required) which has been created inside
		 * project will be deleted
		 */
		file.delete();
		// Store the file in database & return the id 
		return "success";
	}
	
	
	private File convertMultiPartFileToFile(final MultipartFile multipartFile) throws Exception {
		final File convFile = new File(multipartFile.getOriginalFilename());

		/**
		 * File gets created in the project (inside the target folder). The
		 * created file is required for reading it inside the addFilePart()
		 */
		convFile.createNewFile();
		final FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(multipartFile.getBytes());
		fos.close();
		return convFile;
	}
	
	@GetMapping("get-file/{fileId}")
	HttpEntity<byte[]> getFile(@PathVariable("fileId") String objectId, HttpServletResponse response)
			throws Exception {

		GridFSDBFile gridFSDBFile = gridFsTemplate.findOne(new Query(Criteria.where("_id").is(objectId)));
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.valueOf(gridFSDBFile.getContentType()));
		response.setHeader("Content-Disposition", "inline; filename=" + gridFSDBFile.getFilename());
		return new HttpEntity<byte[]>(IOUtils.toByteArray(gridFSDBFile.getInputStream()), headers);
	}
	
	@GetMapping("download-file/{fileId}")
	HttpEntity<byte[]> downloadFile(@PathVariable("fileId") String objectId, HttpServletResponse response)
			throws Exception {

		GridFSDBFile gridFSDBFile = gridFsTemplate.findOne(new Query(Criteria.where("_id").is(objectId)));
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.valueOf(gridFSDBFile.getContentType()));
		response.setHeader("Content-Disposition", "download; filename=" + gridFSDBFile.getFilename());
		return new HttpEntity<byte[]>(IOUtils.toByteArray(gridFSDBFile.getInputStream()), headers);
	}

	
}
