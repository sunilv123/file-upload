package net.thrymr.controllers;

import net.thrymr.beans.GenericResponse;
import net.thrymr.services.ScripService;
import net.thrymr.utils.Constants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/api")
public class DashboardController {

	
	@Autowired
	ScripService scripService;
	
	//getting list of client holding
	@GetMapping("/get-top-and-low-gainers")
	public GenericResponse getClientHoldingList(@RequestHeader("X-Authorization") String xAuth) throws Exception{
		
		System.out.println("getClientHoldingList----------------------");
		return new GenericResponse(Constants.GENERIC_RESPONSE_SUCCESS, scripService.getTopGainersAndLosersList(xAuth));
	}
	
	   //getting list of client by scrip
		@GetMapping("/get-client-list-by-scrip/{scripId}")
		public GenericResponse getClientListByScrip(@RequestHeader("X-Authorization") String xAuth, @PathVariable String scripId) throws Exception{
			System.out.println("getClientListByScrip----------------------");
			return new GenericResponse(Constants.GENERIC_RESPONSE_SUCCESS, scripService.getClientListByScrip(xAuth, scripId));
		}
	
}
