package net.thrymr.controllers;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author buta
 * @createdOn 10-Jul-2017 02:40
 */
@RestController
@CrossOrigin
public class WebSocketController {

}
