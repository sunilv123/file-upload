package net.thrymr.services;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import net.thrymr.models.LTP;
import net.thrymr.repo.LTPRepository;
import net.thrymr.utils.Constants;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class LTPDataService {

	@Autowired
	GeneralService generalService;
	
	@Autowired
	LTPRepository ltpRepository;
	
	@Scheduled(fixedRate=30000)
	public void cronToGetLiveLtpData() throws Exception{
		//System.out.println("cronToGetLiveLtpData---------before--------------->"+new Date());
		saveLtpData(getLtpDataByApi());
	}
	
  public void saveLtpData(String ltpResponse) throws Exception{

	  JSONArray jsonArray = new JSONArray(ltpResponse);
	  
	 // System.out.println("jsonArray----"+jsonArray.length());
	  
	  JSONObject jsonObject = null;
	  LTP ltp = null;
	  
		List<LTP> ltpList = ltpRepository.findAll();
		for (LTP lt : ltpList) {
			ltpRepository.delete(lt);
		}
	  
	  for (int i = 0; i <jsonArray.length(); i++) {
		
		  jsonObject = jsonArray.getJSONObject(i); 
		  
		  if(!jsonObject.get("isin").equals(null)){
			 
			//  System.out.println("isin boolean----"+(!jsonObject.get("isin").equals(null)));
			  
		  ltp = new LTP();
		  
	      ltp.name = jsonObject.getString("name");
	      ltp.isinVal = jsonObject.getString("isin");
		  ltp.exchange = jsonObject.getString("exchange");
		  ltp.symbol = jsonObject.getString("symbol");
		  ltp.series = jsonObject.getString("series");
		  ltp.token = jsonObject.getString("token");
		  
		  if(!jsonObject.get("lastTradedPrice").equals(null)){
			  ltp.lastTradedPrice = jsonObject.getInt("lastTradedPrice");
		  }else{
			  ltp.lastTradedPrice = 0;  
		  }
		  if( !jsonObject.get("timeStamp").equals(null)){
			  ltp.timeStamp = jsonObject.getLong("timeStamp");
		  }else{
			  ltp.timeStamp = 0l; 
		  }
		  if( !jsonObject.get("closingPrice").equals(null)){
			  ltp.closingPrice = (float) jsonObject.getDouble("closingPrice");
		  }else{
			  ltp.closingPrice = 0f; 
		  }
				  
		   ltpRepository.save(ltp);	  
		  }
	  }
	  
	}
	
	public  String getLtpDataByApi() throws Exception {


		// httpget.addHeader("X-API-Key",
		// "11cdbf28-5d1c-4652-8d1c-61d385722e2c");

		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpGet httpget;
		httpget = new HttpGet(Constants.LTP_URL);
		// Create a custom response handler
		ResponseHandler<String> responseHandler = new ResponseHandler<String>() {

			public String handleResponse(final HttpResponse response)
					throws ClientProtocolException, IOException {
				int status = response.getStatusLine().getStatusCode();
				if (status >= 200 && status < 300) {
					HttpEntity entity = response.getEntity();
					return entity != null ? EntityUtils.toString(entity) : null;
				} else {
					throw new ClientProtocolException(
							"Unexpected response status: " + status);
				}
			}
		};

		HttpClientContext context = HttpClientContext.create();
		HttpHost targetHost = new HttpHost(Constants.LTP_HOST,
				Constants.LTP_PORT, "http");
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(new AuthScope(targetHost.getHostName(),
				targetHost.getPort()), new UsernamePasswordCredentials(
				Constants.LTP_USER_NAME, Constants.LTP_PASSWORD));
		AuthCache authCache = new BasicAuthCache();
		BasicScheme basicAuth = new BasicScheme();
		authCache.put(targetHost, basicAuth);
		context.setCredentialsProvider(credsProvider);
		context.setAuthCache(authCache);
		String responseBody = null;
		responseBody = httpclient.execute(httpget, responseHandler, context);

		//System.out.println("responseBody---" + responseBody.toString());

		httpclient.close();

		return responseBody;

	}


/*	
	public ScripBean convertScripToScripBean(Scrip scrip) throws Exception{
		
			
		    LTPBean	ltpBean = new LTPBean();
			
			ltpBean.exchange = json.getString("exchange");
			ltpBean.symbol = json.getString("symbol");
			ltpBean.series = json.getString("series");
			ltpBean.name = json.getString("name");
			ltpBean.lastTradedPrice = json.getInt("lastTradedPrice");
			ltpBean.token = json.getString("token");

			return ltpBean;
	}*/
	
}
