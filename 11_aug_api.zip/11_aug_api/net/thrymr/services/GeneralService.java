package net.thrymr.services;

import java.io.IOException;

import net.thrymr.utils.Constants;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

@Service
public class GeneralService {


	public  String getResponseByApi(String apiUrl) throws Exception {

		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpGet httpget;

		httpget = new HttpGet(apiUrl);
		// httpget.addHeader("X-API-Key",
		// "11cdbf28-5d1c-4652-8d1c-61d385722e2c");

		// Create a custom response handler
		ResponseHandler<String> responseHandler = new ResponseHandler<String>() {

			public String handleResponse(final HttpResponse response)
					throws ClientProtocolException, IOException {
				int status = response.getStatusLine().getStatusCode();
				if (status >= 200 && status < 300) {
					HttpEntity entity = response.getEntity();
					return entity != null ? EntityUtils.toString(entity) : null;
				} else {

					throw new ClientProtocolException(
							"Unexpected response status: " + status);
				}
			}

		};

		HttpClientContext context = HttpClientContext.create();
		HttpHost targetHost = new HttpHost(Constants.LTP_HOST,
				Constants.LTP_PORT, "http");
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(new AuthScope(targetHost.getHostName(),
				targetHost.getPort()), new UsernamePasswordCredentials(
				Constants.LTP_USER_NAME, Constants.LTP_PASSWORD));
		AuthCache authCache = new BasicAuthCache();
		BasicScheme basicAuth = new BasicScheme();
		authCache.put(targetHost, basicAuth);
		context.setCredentialsProvider(credsProvider);
		context.setAuthCache(authCache);
		String responseBody = null;
		responseBody = httpclient.execute(httpget, responseHandler, context);

		System.out.println("responseBody---" + responseBody.toString());

		httpclient.close();

		return responseBody;

	}

	public JSONObject convertToJson(String response) throws Exception {
		return new JSONObject(response);
	}
	
	public String getResponseByApiUsingHeader(String apiUrl) throws Exception{
		
		String responseBody = null;
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpGet httpget;

		 httpget = new HttpGet(apiUrl);
		 httpget.addHeader("token", "Y2ZpOjEyMzQ1Ng==");

		// Create a custom response handler
		ResponseHandler<String> responseHandler = new ResponseHandler<String>() {

			public String handleResponse(final HttpResponse response)
					throws ClientProtocolException, IOException {
				int status = response.getStatusLine().getStatusCode();
				if (status >= 200 && status < 300) {
					HttpEntity entity = response.getEntity();
					return entity != null ? EntityUtils.toString(entity) : null;
				} else {

					throw new ClientProtocolException(
							"Unexpected response status: " + status);
				}
			}

		};
		
		responseBody = httpclient.execute(httpget, responseHandler);

		//System.out.println("responseBody---" + responseBody.toString());

		httpclient.close();

		return responseBody;
		
	}
}
