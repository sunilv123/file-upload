package net.thrymr.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
public class PushMessageService {

	@Autowired
	private SimpMessagingTemplate template;


	public Boolean pushSocketMessage(final String url, final Object object){//here url->/edelweiss-subscribe/receive-direct-message/
		try{
			this.template.convertAndSend(url, object);
			return true;
		}
		catch(final Exception e){
			e.printStackTrace();
		}
		return false;
	}

}
