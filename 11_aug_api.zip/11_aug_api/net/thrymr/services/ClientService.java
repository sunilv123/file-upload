package net.thrymr.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import net.thrymr.beans.ClientBean;
import net.thrymr.models.AppUser;
import net.thrymr.models.AppUserClientInfo;
import net.thrymr.models.Client;
import net.thrymr.models.ClientScripInfo;
import net.thrymr.models.Scrip;
import net.thrymr.models.TempAppUserClientHolding;
import net.thrymr.repo.AppUserClientInfoRepository;
import net.thrymr.repo.ClientRepository;
import net.thrymr.repo.ClientScripInfoRepository;
import net.thrymr.repo.ScripRepository;
import net.thrymr.repo.TempAppUserClientHoldingRepository;
import net.thrymr.utils.Constants;
import net.thrymr.utils.Util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

@Service
public class ClientService {

	
	@Autowired
	ClientRepository clientRepository;
	
	@Autowired
	GeneralService generalService;
	
	@Autowired
	TempAppUserClientHoldingRepository tempAppUserClientHoldingRepository;
	
	@Autowired
	AppUserClientInfoRepository appUserClientInfoRepository;
	
	@Autowired
	ScripRepository scripRepository;
	
	@Autowired
	ClientScripInfoRepository clientScripInfoRepository;
	
	@Autowired
	LoginService loginService;
	
	public void getClientAndScripList(AppUser appUser) throws Exception{
		
		//String apiUrl = Constants.CLIENT_LIST_URL+appUser.userCode;
		String apiUrl = Constants.CLIENT_LIST_URL+15371;
		
		String clientsResponse = generalService.getResponseByApiUsingHeader(apiUrl);
		
		Assert.isTrue(Util.isNotEmpty(clientsResponse), "No client data available");
		
		saveClientList(clientsResponse, appUser);
		
		saveClientScripTempData(appUser);
		
		saveClientHoldingData(appUser);
		
	}

	
	/*Seeting the client list of logged in user*/
	public void saveClientList(String response, AppUser appUser) throws JSONException{
		
		//System.out.println("--response-----------"+response.toString());
		
		JSONObject jsonObject = new JSONObject(response);
		
		JSONObject object = null;
		Client client = null;
		
		   Assert.isTrue((jsonObject.getInt("ResultCode") == 1), "No client data");
		
			JSONArray jsonArray	 = jsonObject.getJSONArray("Payload");
			
			for (int i = 0; i < jsonArray.length(); i++) {
				
				object = jsonArray.getJSONObject(i);
				
				
				client = clientRepository.findByClientCode(object.getString("ClientCode"));
				
				if( client == null){
					
					client = new Client();
					
					client.clientCode = object.getString("ClientCode");
					client.outstandingLoanBalance = new BigDecimal(object.getDouble("OutstandingLoanBalance"));
					client.ROI = (float) object.getDouble("ROI");
					client.name = object.getString("ClientName");
				    
					clientRepository.save(client);
					
					AppUserClientInfo appUserClientInfo = new AppUserClientInfo();
					appUserClientInfo.appUser = appUser;
					appUserClientInfo.client = client;
					
					appUserClientInfoRepository.save(appUserClientInfo);
				
				}
			}
	}
	
	
	   //setting the all scrip for logged in user and if already exist then update
		public void saveClientHoldingData(AppUser appUser) throws Exception{

		    
		   List<Client>  clientList =  clientRepository.findAll();
		   
		   System.out.println("clientList-size----"+clientList.size());
		    
		   for (Client client : clientList) {
			     Scrip scrip = null;
			     ClientScripInfo clientScripInfo = null;
			     
			 List<TempAppUserClientHolding> tempAppUserClientHoldingList =  tempAppUserClientHoldingRepository.findByClientCode(client.clientCode);
			     
			  List<ClientScripInfo> clientScripInfos = clientScripInfoRepository.findByClient(client);
			  
			  for (ClientScripInfo clientScripInfo2 : clientScripInfos) {
				  clientScripInfoRepository.delete(clientScripInfo2);
			  }
			  
			  List<Scrip>scripList = scripRepository.findByClientCode(client.clientCode);
			  
			  for (Scrip scrip2 : scripList) {
				  scripRepository.delete(scrip2);
			  }
			  
			 
              for (TempAppUserClientHolding tempAppUserClientHolding : tempAppUserClientHoldingList) {
				 
				  scrip = new Scrip();
				  clientScripInfo = new ClientScripInfo();
				
				 
				scrip.clientCode = tempAppUserClientHolding.clientCode;
				scrip.ISIN = tempAppUserClientHolding.ISIN;
				scrip.name = tempAppUserClientHolding.name;
				scrip.SecurityScripName = tempAppUserClientHolding.SecurityScripName;
				scrip.FundingPercentage = (float) tempAppUserClientHolding.FundingPercentage;
				scrip.MarginQuantity = tempAppUserClientHolding.MarginQuantity;
				scrip.UnapprovedQuantity = tempAppUserClientHolding.UnapprovedQuantity;
				scrip.TotalQuantity = tempAppUserClientHolding.TotalQuantity;
				scrip.MarketRate = tempAppUserClientHolding.MarketRate;
				scrip.ApprovedMarketValue =  tempAppUserClientHolding.ApprovedMarketValue;
				scrip.NonApprovedMarketValue =  tempAppUserClientHolding.NonApprovedMarketValue;
				scrip.TotalMarketValue = tempAppUserClientHolding.TotalMarketValue;
				scrip.DrawingPower =  tempAppUserClientHolding.DrawingPower;
				
				scripRepository.save(scrip);
				 
				clientScripInfo.scrip = scrip;
				clientScripInfo.client = client;
				clientScripInfo.appUser = appUser;
				
				clientScripInfoRepository.save(clientScripInfo);
			
            }
          	
		   } 
		}


//setting the all scrip for logged in user and if already exist then update
public void saveClientScripTempData(AppUser appUser) throws Exception{
	
   String apiUrl = Constants.CLIENT_HOLDING_URL+15371;
	
    String response = generalService.getResponseByApiUsingHeader(apiUrl);
    
	JSONObject jsonObject = new JSONObject(response);
	
	JSONObject object = null;
	
	Assert.isTrue((jsonObject.getInt("ResultCode") == 1), "No client data");
	
    JSONArray jsonArray	 = jsonObject.getJSONArray("Payload");

    //TempAppUserClientHolding scrip = null;
	    
    System.out.println("--ClientHolding length---------"+jsonArray.length());
    List<TempAppUserClientHolding>scrips = tempAppUserClientHoldingRepository.findByAppUser(appUser);
    
    for (TempAppUserClientHolding tempAppUserClientHolding : scrips) {
    	tempAppUserClientHoldingRepository.delete(tempAppUserClientHolding);
    }
    TempAppUserClientHolding scrip = new  TempAppUserClientHolding();
      for (int i = 0; i < jsonArray.length(); i++) {
		
	 object = jsonArray.getJSONObject(i);
	 
	 scrip = new TempAppUserClientHolding();
	 
	scrip.appUser = appUser;
	scrip.clientCode = object.getString("ClientCode");
	scrip.ISIN = object.getString("ISIN");
	scrip.name = object.getString("ClientName");
	scrip.SecurityScripName = object.getString("SecurityScripName");;
	scrip.FundingPercentage = (float) object.getDouble("FundingPercentage");
	scrip.MarginQuantity = object.getInt("MarginQuantity");
	scrip.UnapprovedQuantity = object.getInt("UnapprovedQuantity");
	scrip.TotalQuantity = object.getInt("TotalQuantity");
	scrip.MarketRate = object.getInt("MarketRate");
	scrip.ApprovedMarketValue =  object.getInt("ApprovedMarketValue");
	scrip.NonApprovedMarketValue =  object.getInt("NonApprovedMarketValue");;
	scrip.TotalMarketValue = object.getInt("TotalMarketValue");;
	scrip.DrawingPower =  new BigDecimal(object.getLong("DrawingPower"));
	
	tempAppUserClientHoldingRepository.save(scrip);
	 
	 
    }

    	  
      
      
}


 public List<ClientBean> jsonClientDataToBean(JSONObject response) throws Exception{
		
		//System.out.println("--response-----------"+response.toString());
		
		List<ClientBean> clientHoldingList = new ArrayList<ClientBean>();
		JSONObject object = null;
		ClientBean clientBean = null;
		
		if(response.getInt("ResultCode") == 1){
		
			JSONArray jsonArray	 = response.getJSONArray("Payload");
			
			for (int i = 0; i < jsonArray.length(); i++) {
				
				clientBean = new ClientBean();
				
				object = jsonArray.getJSONObject(i);
				
				clientBean.ClientCode = object.getString("ClientCode");
				clientBean.name = object.getString("ClientName");
				clientBean.ISIN = object.getString("ISIN");
				clientBean.SecurityScripName = object.getString("SecurityScripName");
				clientBean.FundingPercentage = object.getInt("FundingPercentage");
				clientBean.MarginQuantity = object.getInt("MarginQuantity");
				clientBean.UnapprovedQuantity = object.getInt("UnapprovedQuantity");
				clientBean.TotalQuantity = object.getInt("TotalQuantity");
				clientBean.MarketRate = object.getInt("MarketRate");
				clientBean.ApprovedMarketValue = object.getInt("ApprovedMarketValue");
				clientBean.NonApprovedMarketValue = object.getInt("NonApprovedMarketValue");
				clientBean.TotalMarketValue = object.getInt("TotalMarketValue");
				clientBean.drawingPower = new BigDecimal(object.getLong("DrawingPower"));
				
				clientHoldingList.add(clientBean);
			}
		}
		
		return clientHoldingList;
	}

}
