package net.thrymr.services;

import java.util.Date;
import java.util.Hashtable;
import java.util.UUID;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import net.thrymr.beans.LoginBean;
import net.thrymr.models.AppUser;
import net.thrymr.models.LoginData;
import net.thrymr.models.LoginStatus;
import net.thrymr.repo.AppUserRepository;
import net.thrymr.repo.LoginDataRepository;
import net.thrymr.utils.Constants;

@Service
public class LoginService {
	
	@Autowired
	LoginDataRepository loginDataRepository;
	
	@Autowired
	AppUserRepository appUserRepository;
	
	@Autowired
	ClientService clientService;

//
//	@Scheduled(fixedRate=5000)
//	public void cron(){
//		//final String s = new SimpleDateFormat("HH:mm:ss").format(new Date());
//		//System.out.println(s);
//		//		final ArrayList<String> list = new ArrayList<String>();
//		//		list.add(s);
//		this.pushMessageService.pushSocketMessage("/edelweiss-subscribe/receive-message", new GenericResponse("", new Date().getTime()));
//	}

	public LoginBean findUserInLDAP(LoginBean loginBean, HttpServletRequest request) throws Exception{
		
		   System.out.println("hi login ldap");     
			StringBuilder builder = new StringBuilder();
			
			builder.append("(|");
			builder.append("(samaccountname=" + loginBean.userName + "*)");
			builder.append(")");

			String username = "EDELCAP\\" + loginBean.userName;
		    //TODO set ldap url

			Hashtable<String, String> env = new Hashtable<String, String>();
			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			env.put(Context.PROVIDER_URL, Constants.LDAP_URL);
			env.put(Context.SECURITY_AUTHENTICATION, "simple");
			env.put(Context.SECURITY_PRINCIPAL, username);
			env.put(Context.SECURITY_CREDENTIALS, loginBean.password);
			env.put("com.sun.jndi.ldap.read.timeout", "60000");

				DirContext ctx = new InitialDirContext(env);

				SearchControls searchCtls = new SearchControls();

				String returnedAtts[] = { "givenName", "sn", "Description", "mail", "cn", "telephonenumber",
						"samaccountname", "OU" };
				searchCtls.setReturningAttributes(returnedAtts);

				searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);

				String searchFilter = builder.toString();

				String searchBase = "DC=EDELCAP,DC=COM";

				NamingEnumeration<?> answer = ctx.search(searchBase, searchFilter, searchCtls);

				while (answer.hasMoreElements()) {
					SearchResult sr = (SearchResult) answer.next();
					Attributes attrs = sr.getAttributes();
					if (attrs != null) {
							if (attrs.get("Description").get() != null && attrs.get("givenName").get() != null
									&& attrs.get("sn").get() != null && attrs.get("mail").get() != null
									&& attrs.get("mail").get() != null && attrs.get("samaccountname").get() != null) {
								
							
							AppUser appUser = null;
							
							appUser = appUserRepository.findByUserCode(attrs.get("Description").get().toString());
							
							if(appUser == null){
								
								appUser = new AppUser();
								appUser.userCode = attrs.get("Description").get().toString();
								appUser.firstName = attrs.get("givenName").get().toString();
								appUser.lastName = attrs.get("sn").get().toString();
								appUser.domain = "edelcap";
								appUser.email = attrs.get("mail").get().toString();
								appUser.userName = attrs.get("samaccountname").get().toString().toLowerCase();
								
								appUserRepository.save(appUser);
							}
							
							clientService.getClientAndScripList(appUser);
							
							return getLoggedInUserData(appUser, request.getRequestURL().toString(), request.getRemoteAddr());
							
							} 
					}
				}
			
		return null;
	}
	
	public String processLogin(final AppUser appUser, final String url, final String ipAddress) throws Exception {
		final LoginData loginData = new LoginData();

		final Date date = new Date();
		loginData.appUser = appUser;
		final String authToken = this.getAuthToken();
		loginData.xAuth = authToken/*
		 * PlatformUtils.getHashedString(authToken)
		 */;
		loginData.expiryTime = System.currentTimeMillis() + Constants.SESSION_EXPIRY_TIME;
		loginData.loginStatus = LoginStatus.LOGGED_IN;
		loginData.logInDate = date;
		this.loginDataRepository.save(loginData);

		return authToken;
	}
	
	private String getAuthToken() throws Exception {
		final String token = UUID.randomUUID().toString();
		if (this.loginDataRepository.findByXAuth(token) != null) {
			this.getAuthToken();
		}
		return token;
	}

	public AppUser getLoggedInAppUser(final String xAuth) throws Exception {
		final LoginData loginData = this.loginDataRepository
				.findByXAuth(xAuth/* PlatformUtils.getHashedString(xAuth) */);
		return this.isLoggedIn(xAuth) ? loginData.appUser : null;
	}

	public boolean isLoggedIn(final String xAuthToken) throws Exception {
		boolean isLoggedIn = false;

		final LoginData loginData = this.loginDataRepository
				.findByXAuth(xAuthToken/*
				 * PlatformUtils.getHashehttp://demo.
				 * platform.ooodString(xAuthToken)
				 */);
		if ((loginData != null) && (loginData.loginStatus == LoginStatus.LOGGED_IN)) {
			isLoggedIn = true;
			/** TODO : Use below code for implementing session expiry time */
			// if (loginData.expiryTime > System.currentTimeMillis()) {
			// loginData.expiryTime = System.currentTimeMillis() +
			// Constants.SESSION_EXPIRY_TIME;
			// isLoggedIn = true;
			// } else {
			// loginData.loginSessionStatus = LoginSessionStatus.EXPIRED;
			// }
			// TODO : Need to solve
			// org.springframework.orm.ObjectOptimisticLockingFailureException
			// by removing below comment
			// this.loginDataRepository.saveAndFlush(loginData);
		}
		return isLoggedIn;
	}

	public LoginBean getLoggedInUserData(AppUser appUser, final String url, final String ipAddress) throws Exception{

		final LoginBean loginResponse = new LoginBean();
		final String xAuth = this.processLogin(appUser, url, ipAddress);
		loginResponse.xAuth = xAuth;
		loginResponse.appUserId = appUser.id;
		loginResponse.firstName = appUser.firstName;
		loginResponse.lastName = appUser.lastName;
		
		return loginResponse;
	}
	
	public LoginData logout(final String xAuthToken, final String url, final String ipAddress) throws Exception {
		final LoginData loginData = this.loginDataRepository.findByXAuth(
				xAuthToken/* PlatformUtils.getHashedString(xAuthToken) */);
		Assert.isTrue(loginData != null, "Please login to access the service");
		// Assert.isTrue(loginData.loginSessionStatus ==
		// LoginSessionStatus.LOGGED_IN, "You had already logged out");
		final Date date = new Date();
		this.loginDataRepository.findByAppUserAndLoginStatus(loginData.appUser, LoginStatus.LOGGED_IN)
		.forEach(l -> {
			l.loginStatus = LoginStatus.EXPIRED;
			l.logOutDate = date;
			this.loginDataRepository.save(l);

		});
		return loginData.loginStatus.equals(LoginStatus.EXPIRED) ? loginData : null;
	}

}
