package net.thrymr.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.thrymr.beans.ClientBean;
import net.thrymr.beans.ScripBean;
import net.thrymr.models.AppUser;
import net.thrymr.models.Client;
import net.thrymr.models.ClientScripInfo;
import net.thrymr.models.LTP;
import net.thrymr.models.Scrip;
import net.thrymr.repo.ClientScripInfoRepository;
import net.thrymr.repo.LTPRepository;
import net.thrymr.repo.ScripRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

@Service
public class ScripService {

	@Autowired
	GeneralService generalService;

	@Autowired
	LoginService loginService;

	@Autowired
	ClientScripInfoRepository clientScripInfoRepository;

	@Autowired
	LTPRepository lTPRepository;

	@Autowired
	ScripRepository scripRepository;

	public Map<String, List<ScripBean>> getTopGainersAndLosersList(String xAuth)
			throws Exception {

		AppUser appUser = loginService.getLoggedInAppUser(xAuth);
		return calculateTopGainersAndLosersFromScripList(calculateTopGainersAndLosers(appUser));
	}

	public List<ClientBean> getClientListByScrip(String xAuth, String scripId)
			throws Exception {
		AppUser appUser = loginService.getLoggedInAppUser(xAuth);
		
		Assert.isTrue(appUser != null, "Please login to continue");

		Scrip scrip = scripRepository.findOne(scripId);

		List<ClientScripInfo> clientScripInfoList = clientScripInfoRepository.findByScrip(scrip);
		
		System.out.println("------clientScripInfoList----"+clientScripInfoList.size()+"-----"+scrip.id);
		
		List<ClientBean> clientList = new ArrayList<ClientBean>();
		clientScripInfoList.stream().forEach(
				clientScripInfo -> {

					clientList.add(mapClientToClientBean(
							clientScripInfo.client, scrip));

				});

		return clientList;
	}

	public ClientBean mapClientToClientBean(Client client, Scrip scrip) {

		ClientBean clientBean = new ClientBean();

		clientBean.name = client.name;
		clientBean.drawingPower = scrip.DrawingPower;

		return clientBean;
	}

	public List<ScripBean> calculateTopGainersAndLosers(AppUser appUser)
			throws Exception {

		List<ClientScripInfo> clientScripInfoList = clientScripInfoRepository
				.findByAppUser(appUser);

		// System.out.println("--clientScripInfoList size-----"+clientScripInfoList.size());

		List<LTP> ltps = null;

		LTP ltp = null;

		Scrip scrip = null;

		List<ScripBean> scripBeanList = new ArrayList<ScripBean>();

		for (ClientScripInfo clientScripInfo : clientScripInfoList) {

			ltps = new ArrayList<LTP>();
			scrip = clientScripInfo.scrip;
			ltps = lTPRepository
					.findByIsinValOrderByTimeStampDesc(clientScripInfo.scrip.ISIN);

			if (!ltps.isEmpty()) {
				ltp = ltps.get(0);

				if (ltp != null) {

					ScripBean scripBean = new ScripBean();
					scripBean.scripId = scrip.id;

					scripBean.drawingPower = scrip.DrawingPower;
					if (ltp.closingPrice != 0f) {
						scripBean.percentChange = ((ltp.lastTradedPrice / 100 - ltp.closingPrice) / ltp.closingPrice) * 100; // (CMP-Previous
																																// Day
																																// Closing
																																// price/Previous
																																// Day
																																// Closing
																																// price)*100;
					} else {
						scripBean.percentChange = 0f;
					}
					scripBean.name = scrip.name;

					scripBeanList.add(scripBean);
				}
			}

		}

		return scripBeanList;
	}

	public Map<String, List<ScripBean>> calculateTopGainersAndLosersFromScripList(
			List<ScripBean> scripBeanList) throws Exception {

		List<ScripBean> gainerList = new ArrayList<ScripBean>();

		List<ScripBean> loserList = new ArrayList<ScripBean>();

		Map<String, List<ScripBean>> map = new HashMap<String, List<ScripBean>>();

		for (ScripBean scripBean : scripBeanList) {

			if (scripBean.percentChange > 0f) {
				gainerList.add(scripBean);
			} else if (scripBean.percentChange < 0f) {
				loserList.add(scripBean);
			}

		}

		gainerList.sort((p1, p2) -> p2.percentChange
				.compareTo(p1.percentChange));
		loserList
				.sort((p1, p2) -> p2.percentChange.compareTo(p1.percentChange));

		map.put("gainerList", gainerList);
		map.put("loserList", loserList);

		return map;
	}
}
