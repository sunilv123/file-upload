package net.thrymr.beans;

public class LoginBean {

	public String appUserId;

	public String userName;

	public String password;
	
	public String xAuth;

	public String firstName;

	public String lastName;

	public String role;

	public Boolean isActive;

	public String email;

	

}
