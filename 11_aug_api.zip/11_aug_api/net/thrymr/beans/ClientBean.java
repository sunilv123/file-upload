package net.thrymr.beans;

import java.math.BigDecimal;

public class ClientBean {

	public String ClientCode;
	
	public String name;
	
	public String ISIN;
	
	public String SecurityScripName;
	
	public Integer FundingPercentage;
	
	public Integer MarginQuantity;
	
	public Integer UnapprovedQuantity;
	
	public Integer TotalQuantity;
	
	public Integer MarketRate;
	
	public Integer ApprovedMarketValue;
	
	public Integer NonApprovedMarketValue;
	
	public Integer TotalMarketValue;
	
	public BigDecimal drawingPower;

	
}
