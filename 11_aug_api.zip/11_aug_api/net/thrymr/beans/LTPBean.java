package net.thrymr.beans;

public class LTPBean {

	public String exchange;
	
	public String symbol;
	
	public String series;
	
	public String name;
	
	public Integer lastTradedPrice;//current market price(/100)
	
	public String token;
	
	public String isin;
	
	public Long timeStamp;
	
	public Float closingPrice;//last day closing price
}

