package net.thrymr.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author buta
 * @createdOn 20-Jul-2017 03:03
 */
@JsonInclude(value = Include.NON_NULL)
public class GenericResponse {

	public String status;

	public Object payLoad;

	public String errorMessage;

	public String xAuth;


	public GenericResponse(String status, final Object payLoad) {
		super();
		this.status = status;
		this.payLoad = payLoad;
	}
	public GenericResponse(String status, final String errorMessage) {
		super();
		this.status = status;
		this.errorMessage = errorMessage;
	}
	public GenericResponse(final String xAuth) {
		super();
		this.xAuth = xAuth;
	}
}
