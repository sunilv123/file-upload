package net.thrymr.beans;

public enum ReturnType {

	//	WHITE_LIST,
	//
	//	ONLINE_LIST,
	//
	//	MORE_MESSAGES,
	//
	//	DIRECT_MESSAGE,
	//
	//	GROUP_MESSAGE,
	//
	//	NEW_GROUP,
	//
	//	NEW_CHATTER

}
