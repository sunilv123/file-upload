package net.thrymr.beans;

import java.math.BigDecimal;

public class ScripBean {
	
	public String scripId;
	
	public Float percentChange;
	
	public BigDecimal drawingPower;
	
	public String ISIN;
	
	public Object nseSymbol;
	
	public Object nseSeries;
	
	public Integer bseCode;
	
	public String bseSeries;
	
	public String name;
	
	public String group;

}
