package net.thrymr.utils;

public class Constants {

	public static final String GENERIC_RESPONSE_SUCCESS = "SUCCESS";

	public static final String GENERIC_RESPONSE_FAILURE = "FAILURE";
	
	public static final Long SESSION_EXPIRY_TIME = 432000000l;
	
	public static final String CLINET_HOLDING_LIST  ="http://10.250.19.39:9122/api/Report/ClientHolding?lob=PB&empcode=15371";
	
	public static final String LDAP_URL = "ldap://gc.edelcap.com:389";

	public static final String LTP_URL = "http://10.250.16.91:8383/orion/api/ltp";
	
	public static final String LTP_HOST = "10.250.16.91";
	
	public static final Integer LTP_PORT = 8383;
	
	public static final String LTP_USER_NAME = "javaauth";
	
	public static final String LTP_PASSWORD = "riskwall@2016";
	
	public static final String CLIENT_LIST_URL = "http://10.250.19.39:9122/api/ClientMaster/OutstandingBalance?lob=PB&empcode=";
	
	public static final String CLIENT_HOLDING_URL = "http://10.250.19.39:9122/api/Report/ClientHolding?lob=PB&empcode=";
}

