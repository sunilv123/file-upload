package net.thrymr.utils;

public class Util {
	
 public static Boolean isNotEmpty(String value){
	 return value != null && ! value.trim().isEmpty();
 }
	
}
