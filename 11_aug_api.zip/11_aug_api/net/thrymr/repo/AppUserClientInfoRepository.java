package net.thrymr.repo;

import java.util.List;

import net.thrymr.models.AppUser;
import net.thrymr.models.AppUserClientInfo;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface AppUserClientInfoRepository extends MongoRepository<AppUserClientInfo, String> {

	List<AppUserClientInfo> findByAppUser(AppUser appUser);
	
}
