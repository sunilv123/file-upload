package net.thrymr.repo;

import net.thrymr.models.CircuitFilter;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface CircuitFilterRepository extends MongoRepository<CircuitFilter, String>{

	
	
}
