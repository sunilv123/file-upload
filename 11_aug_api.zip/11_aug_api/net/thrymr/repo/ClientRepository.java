package net.thrymr.repo;

import net.thrymr.models.Client;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface ClientRepository extends MongoRepository<Client, String> {

	Client findById(String id);
	
	Client findByClientCode(String clientCode);

}
