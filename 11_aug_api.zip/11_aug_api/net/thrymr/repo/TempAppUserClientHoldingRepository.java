package net.thrymr.repo;

import java.util.List;

import net.thrymr.models.AppUser;
import net.thrymr.models.TempAppUserClientHolding;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface TempAppUserClientHoldingRepository extends MongoRepository<TempAppUserClientHolding, String>{

	List<TempAppUserClientHolding> findByClientCode(String ClientCode);
	
	List<TempAppUserClientHolding> findByAppUser(AppUser appUser);
	
}
