package net.thrymr.repo;

import java.util.List;

import net.thrymr.models.LTP;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface LTPRepository extends MongoRepository<LTP, String>{

 List<LTP>	findByIsinValOrderByTimeStampDesc(String isinValue);
	
}
