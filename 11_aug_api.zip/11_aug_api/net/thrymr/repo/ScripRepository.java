package net.thrymr.repo;

import java.util.List;

import net.thrymr.models.Scrip;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface ScripRepository extends MongoRepository<Scrip, String>{

	List<Scrip> findByClientCode(String ClientCode);
	
}
