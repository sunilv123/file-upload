package net.thrymr.repo;

import net.thrymr.models.PledgeData;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface PledgeDataRepository extends MongoRepository<PledgeData, String>{

}
