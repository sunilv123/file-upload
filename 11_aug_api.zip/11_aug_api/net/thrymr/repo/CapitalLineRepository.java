package net.thrymr.repo;

import net.thrymr.models.CapitalLine;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface CapitalLineRepository extends MongoRepository<CapitalLine, String>{

}
