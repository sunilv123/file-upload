package net.thrymr.repo;

import net.thrymr.models.AppUser;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface AppUserRepository extends MongoRepository<AppUser, String> {

	
	AppUser findByUserCode(String userCode);

}
