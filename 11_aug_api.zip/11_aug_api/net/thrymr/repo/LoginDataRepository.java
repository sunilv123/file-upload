package net.thrymr.repo;

import java.util.List;

import net.thrymr.models.AppUser;
import net.thrymr.models.LoginData;
import net.thrymr.models.LoginStatus;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface LoginDataRepository extends MongoRepository<LoginData, String> {

	/**
	 * @param appUser
	 * @param false1
	 * @return
	 */
	// List<LoginData> findByAppUserAndIsActive(AppUser appUser, Boolean flag);

	/**
	 * @param encrypt
	 * @return
	 */
	LoginData findByXAuth(String authToken);

	/**
	 * @param appUser
	 * @return
	 */
	List<LoginData> findByAppUser(AppUser appUser);

	/**
	 * @param appUser
	 * @return
	 */
	List<LoginData> findByAppUserAndLoginStatus(AppUser appUser, LoginStatus loginStatus);

}
