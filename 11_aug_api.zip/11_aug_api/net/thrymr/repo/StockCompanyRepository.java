package net.thrymr.repo;

import net.thrymr.models.Scrip;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface StockCompanyRepository extends MongoRepository<Scrip, String> {

}
