package net.thrymr.repo;

import java.util.List;

import net.thrymr.models.AppUser;
import net.thrymr.models.Client;
import net.thrymr.models.ClientScripInfo;
import net.thrymr.models.Scrip;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface ClientScripInfoRepository extends MongoRepository<ClientScripInfo, String> {

	List<ClientScripInfo> findByClient(Client client);
	
	List<ClientScripInfo> findByScrip(Scrip scrip);
	
	List<ClientScripInfo> findByAppUser(AppUser appUser);
	
}
