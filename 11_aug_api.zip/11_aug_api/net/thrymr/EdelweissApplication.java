package net.thrymr;

import net.thrymr.config.AppConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;

//@SpringBootApplication
public class EdelweissApplication {

	static Logger logger = LoggerFactory.getLogger(EdelweissApplication.class);

	public static void main(String[] args) throws Exception {
		try {
			// SpringApplication.run(AppConfig.class, args);
			SpringApplication.run(AppConfig.class, args);
		} catch (Exception ex) {
			ex.printStackTrace();
			// logger.error(ExceptionUtils.getStackTrace(ex));
		}
	}
}
